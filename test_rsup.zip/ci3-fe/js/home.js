document.addEventListener("DOMContentLoaded", () => {
    const logoutBtn = document.getElementById("logoutBtn");
    const articleList = document.getElementById("articleList");
    const createBtn = document.getElementById("createBtn");
  
    let currentPage = 1;
    const limit = 3;
    let currentSearch = "";
    let userRole = "";
  
    // Cek session login dan dapatkan role
    fetch(`${API_BASE_URL}/Login_api/check_session`, { credentials: "include" })
      .then(res => res.json())
      .then(data => {
        if (!data.status) {
          window.location.href = "login.html";
        } else {
          userRole = data.role;
          if (userRole === "admin" || userRole === "editor") {
            createBtn.style.display = "inline-block";
          } else {
            createBtn.style.display = "none";
          }
          loadArticles();
        }
      })
      .catch(() => window.location.href = "login.html");
  
    // Pencarian
    document.getElementById("searchBtn").addEventListener("click", () => {
      currentSearch = document.getElementById("searchInput").value.trim();
      loadArticles(1);
    });
  
    document.getElementById("clearSearchBtn").addEventListener("click", () => {
      document.getElementById("searchInput").value = "";
      currentSearch = "";
      loadArticles(1);
    });
  
    function loadArticles(page = 1) {
      fetch(`${API_BASE_URL}/Article_api/index?page=${page}&limit=${limit}&search=${encodeURIComponent(currentSearch)}`)
        .then(res => res.json())
        .then(data => {
          if (data.status) {
            articleList.innerHTML = "";
            const pageInfo = document.getElementById("pageInfo");
            data.data.forEach(article => {
              const articleDiv = document.createElement("div");
              articleDiv.classList.add("article-item");
              articleDiv.innerHTML = `
                <h3>${article.title}</h3>
                <p>${article.content.substring(0, 100)}...</p>
                <small>Oleh: ${article.author} | ${article.created_at}</small>
                <br>
              `;
  
              // Tombol edit
              if (userRole === "admin" || userRole === "editor") {
                const editBtn = document.createElement("button");
                editBtn.classList.add("editBtn");
                editBtn.textContent = "Edit";
                editBtn.addEventListener("click", () => {
                  window.location.href = `edit.html?id=${article.id}`;
                });
                articleDiv.appendChild(editBtn);
              }
  
              // Tombol delete hanya admin
              if (userRole === "admin") {
                const deleteBtn = document.createElement("button");
                deleteBtn.classList.add("deleteBtn");
                deleteBtn.textContent = "Delete";
                deleteBtn.addEventListener("click", () => {
                  if (confirm(`Yakin ingin menghapus artikel "${article.title}"?`)) {
                    fetch(`${API_BASE_URL}/Article_api/delete/${article.id}`, {
                      method: "DELETE",
                    })
                      .then(res => res.json())
                      .then(result => {
                        if (result.status) {
                          alert("Artikel berhasil dihapus!");
                          loadArticles(currentPage);
                        } else {
                          alert("Gagal menghapus artikel.");
                        }
                      })
                      .catch(err => {
                        console.error("Error:", err);
                        alert("Terjadi kesalahan saat menghapus.");
                      });
                  }
                });
                articleDiv.appendChild(deleteBtn);
              }
  
              articleList.appendChild(articleDiv);
            });
  
            currentPage = data.page;
            pageInfo.textContent = `Halaman ${data.page} dari ${data.total_pages}`;
            document.getElementById("prevBtn").disabled = currentPage === 1;
            document.getElementById("nextBtn").disabled = currentPage === data.total_pages;
          }
        });
    }
  
    document.getElementById("prevBtn").addEventListener("click", () => {
      if (currentPage > 1) {
        loadArticles(currentPage - 1);
      }
    });
  
    document.getElementById("nextBtn").addEventListener("click", () => {
      loadArticles(currentPage + 1);
    });
  
    logoutBtn.addEventListener("click", () => {
      fetch(`${API_BASE_URL}/Login_api/logout`, {
        credentials: "include"
      }).then(() => {
        window.location.href = "login.html";
      });
    });
  
    createBtn.addEventListener("click", () => {
      window.location.href = "create.html";
    });
  });
  