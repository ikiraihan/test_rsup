document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const recaptchaResponse = grecaptcha.getResponse();
  const message = document.getElementById("message");

  if (!recaptchaResponse) {
    message.style.color = "red";
    message.textContent = "Selesaikan captcha terlebih dahulu.";
    return;
  }

  fetch(`${API_BASE_URL}/Login_api/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      username,
      password,
      recaptcha: recaptchaResponse
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.status) {
      window.location.href = "home.html";
    } else {
      message.style.color = "red";
      message.textContent = data.message;
      grecaptcha.reset();
    }
  })
  .catch(err => {
    message.style.color = "red";
    message.textContent = "Gagal menghubungi server.";
  });
});
