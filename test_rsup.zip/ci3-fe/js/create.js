document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("createForm");
  const message = document.getElementById("message");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;
    const image = document.getElementById("image").value;
    const author = document.getElementById("author").value;

    fetch(`${API_BASE_URL}/Article_api/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ title, content, image, author })
    })
    .then(res => res.json())
    .then(data => {
      if (data.status) {

        localStorage.setItem("createSuccessMessage", data.message || "Artikel berhasil ditambahkan");
        window.location.href = "home.html";
      } else {
        message.style.color = "red";
        message.textContent = data.message || "Gagal menambahkan artikel";
      }
    })
    .catch(err => {
      message.style.color = "red";
      message.textContent = "Terjadi kesalahan: " + err.message;
    });
  });
  document.getElementById("backBtn").addEventListener("click", () => {
    window.location.href = "home.html";
  });
  
});
