document.addEventListener("DOMContentLoaded", () => {
    const id = new URLSearchParams(window.location.search).get("id");
    const title = document.getElementById("title");
    const content = document.getElementById("content");
    // const image = document.getElementById("image");
    const author = document.getElementById("author");
    const message = document.getElementById("message");
    const backBtn = document.getElementById("backBtn");
  
    fetch(`${API_BASE_URL}/Article_api/show/${id}`)
      .then(res => res.json())
      .then(data => {
        if (data.status && data.data) {
          title.value = data.data.title;
          content.value = data.data.content;
        //   image.value = data.data.image || "";
          author.value = data.data.author;
        }
      });
  
    document.getElementById("editForm").addEventListener("submit", (e) => {
      e.preventDefault();
  
      fetch(`${API_BASE_URL}/Article_api/update/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.value,
          content: content.value,
        //   image: image.value,
          author: author.value,
        }),
      })
        .then(res => res.json())
        .then(data => {
          if (data.status) {
            window.location.href = "home.html?notif=updated";
          } else {
            message.textContent = data.message || "Gagal update";
            message.style.color = "red";
          }
        });
    });
  
    backBtn.addEventListener("click", () => {
      window.location.href = "home.html";
    });
  });
  