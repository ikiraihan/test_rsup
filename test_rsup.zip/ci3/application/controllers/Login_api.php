<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_api extends CI_Controller {
    private $secret_key = '6Ld9dxIrAAAAAA30m8tLz2fzf6rBSxMwubQGCHIT';

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function login() {
        $json = json_decode(file_get_contents("php://input"), true);
        $username = $json['username'] ?? '';
        $password = $json['password'] ?? '';
        $captcha = $json['recaptcha'] ?? '';

        if (empty($username) || empty($password) || empty($captcha)) {
            return $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Semua field wajib diisi.'
            ]));
        }

        $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$this->secret_key}&response={$captcha}");
        $captcha_result = json_decode($verify, true);

        if (!$captcha_result['success']) {
            return $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Captcha tidak valid.'
            ]));
        }

        $user = $this->User_model->get_by_username($username);

        if ($user && password_verify($password, $user->password)) {
            $this->session->set_userdata([
                'logged_in' => true,
                'user_id' => $user->id,
                'username' => $user->username,
                'role' => $user->role
            ]);

            return $this->output->set_content_type('application/json')->set_output(json_encode([
                'status'  => true,
                'message' => 'Login berhasil',
                'data'    => [
                    'username' => $user->username,
                    'role'     => $user->role
                ]
            ]));
        }

        return $this->output->set_content_type('application/json')->set_output(json_encode([
            'status' => false,
            'message' => 'Username atau password salah.'
        ]));
    }

    public function check_session() {
        if ($this->session->userdata('logged_in')) {
            return $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => true,
                'username' => $this->session->userdata('username'),
                'role' => $this->session->userdata('role')
            ]));
        }

        return $this->output->set_content_type('application/json')->set_output(json_encode([
            'status' => false,
            'message' => 'Belum login.'
        ]));
    }

    public function logout() {
        $this->session->sess_destroy();
        return $this->output->set_content_type('application/json')->set_output(json_encode([
            'status' => true,
            'message' => 'Logout berhasil.'
        ]));
    }
}