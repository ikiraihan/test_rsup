<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_seeder extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function insert_users() {
        $users = [
            [
                'username' => 'admin',
                'password' => password_hash('admin123', PASSWORD_BCRYPT),
                'name'     => 'Administrator',
                'role'     => 'admin'
            ],
            [
                'username' => 'user',
                'password' => password_hash('user123', PASSWORD_BCRYPT),
                'name'     => 'User',
                'role'     => 'user'
            ],
            [
                'username' => 'editor',
                'password' => password_hash('editor123', PASSWORD_BCRYPT),
                'name'     => 'Editor',
                'role'     => 'editor'
            ],
        ];

        foreach ($users as $user) {
            $this->db->insert('users', $user);
        }

        echo 'done';
    }
}