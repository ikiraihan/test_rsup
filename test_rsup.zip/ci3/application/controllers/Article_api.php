<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article_api extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Article_model');
        $this->load->helper(['url', 'text']);
    }

    public function index() {
        $limit  = $this->input->get('limit') ?? 10;
        $page   = $this->input->get('page') ?? 1;
        $search = $this->input->get('search');
        $offset = ($page - 1) * $limit;
    
        $articles = $this->Article_model->get_all($limit, $offset, $search);
        $total    = $this->Article_model->count_all($search);
    
        $response = [
            'status' => true,
            'page' => (int)$page,
            'limit' => (int)$limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit),
            'data' => $articles
        ];
    
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }
    
    
    public function show($id) {
        $article = $this->Article_model->get_by_id($id);
        if ($article) {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['status' => true, 'data' => $article]));
        } else {
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode(['status' => false, 'message' => 'Artikel tidak ditemukan']));
        }
    }
    

    public function create() {
        $data = json_decode(file_get_contents("php://input"), true);
        $insert = [
            'title'   => $data['title'],
            'slug'    => url_title($data['title'], 'dash', TRUE),
            'content' => $data['content'],
            'image'   => $data['image'] ?? null,
            'author'  => $data['author']
        ];
        $this->Article_model->create($insert);

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['status' => true, 'message' => 'Artikel berhasil ditambahkan']));
    }

    public function update($id) {
        $data = json_decode(file_get_contents("php://input"), true);
        $update = [
            'title'   => $data['title'],
            'slug'    => url_title($data['title'], 'dash', TRUE),
            'content' => $data['content'],
            'image'   => $data['image'] ?? null,
            'author'  => $data['author'],
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->Article_model->update($id, $update);

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['status' => true, 'message' => 'Artikel berhasil diupdate']));
    }

    public function delete($id) {
        $this->Article_model->delete($id);
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode(['status' => true, 'message' => 'Artikel berhasil dihapus']));
    }
}
